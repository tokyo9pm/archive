export interface CustomFieldContextOption {
  id: string;
  value: string;
  optionId?: string;
  disabled?: boolean;
}
