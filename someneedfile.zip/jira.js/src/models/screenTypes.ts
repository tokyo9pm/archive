export interface ScreenTypes {
  edit?: number;
  create?: number;
  view?: number;
  default?: number;
}
