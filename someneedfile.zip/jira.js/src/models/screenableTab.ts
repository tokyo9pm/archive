export interface ScreenableTab {
  id?: number;
  name: string;
}
