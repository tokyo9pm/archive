export interface ScreenSchemeId {
  id: number;
}
