export interface ScreenableField {
  id: string;
  name: string;
}
