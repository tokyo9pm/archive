export type Callback<T = any> = (err: any | null, data?: T) => void;
